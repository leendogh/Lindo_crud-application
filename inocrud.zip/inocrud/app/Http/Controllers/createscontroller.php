<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\article;

class createscontroller extends Controller
{
    public function home(){
        $articles = article::all();
        Return view('home',['articles'=>$articles]);
    }
    public function add(Request $request){
        $this->validate($request,[

            'title'=>'required',
            'description'=>'required'
        ]);

        $articles = new article;
        $articles->title=$request->input('title');
        $articles->description=$request->input('description');
        $articles->save();
        Return redirect('/')->with('info','Article saved successfuly');
    }
    public function update($id){
        $articles = article::find($id);
       
        Return view('update',['articles'=>$articles]);
    }
    public function edit(Request $request,$id){
        $this->validate($request,[

            'title'=>'required',
            'description'=>'required'
        ]);
        $data = array (
            'title' =>$request->input('title'),
            'description' =>$request->input('description')
        );
        article::where('id',$id)
        ->update($data);
        Return redirect('/')->with('info','Article updated successfuly');
    }
    
    public function read($id){
        $articles = article::find($id);
        Return view('read',['articles'=>$articles]);
    }

    public function delete($id){
        article::where('id',$id)
        ->delete();
        Return redirect('/')->with('info','Article deleted successfuly');
    }
}
