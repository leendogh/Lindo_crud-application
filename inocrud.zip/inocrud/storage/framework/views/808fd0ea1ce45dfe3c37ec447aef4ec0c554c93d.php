<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<div class="container">
    <div class="row">
     <legend><h4>INOFINITY CRUD APPLICATION</h4></legend> 
     
     <?php if(session('info')): ?>

     <div class="alert alert-dismissible alert-success">

        <?php echo e(session('info')); ?>


      </div>
      <?php endif; ?>
    
     
<table class="table table-hover">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Title</th>
            <th scope="col">Description</th>
            <th scope="col">Action</th>
            
          </tr>
        </thead>
        <tbody>
         <?php if(count($articles) >0): ?>
         <?php $__currentLoopData = $articles->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
          <tr>
           
            <td><?php echo e($articles->id); ?></td>
            <td><?php echo e($articles->title); ?></td>
            <td><?php echo e($articles->description); ?></td>
            <td>
              <a href='<?php echo e(url("/read/{$articles->id}")); ?>' class="btn btn-success btn-sm">Read  </a>
              <a href='<?php echo e(url("/update/{$articles->id}")); ?>' class="btn btn-warning btn-sm"">Update</a>
              <a href='<?php echo e(url("/delete/{$articles->id}")); ?>' class="btn btn-danger btn-sm" >Delete  </a>   
              
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table> 
    </div>


      

</div>
<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>