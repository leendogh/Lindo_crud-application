<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<div class="container">
    
     <legend><h4>READ INOFINITY POST</h4></legend>
     <hr>

     <p class="lead"><?php echo e($articles->title); ?></p>
     <p><?php echo e($articles->description); ?></p>
    
</div>
<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>