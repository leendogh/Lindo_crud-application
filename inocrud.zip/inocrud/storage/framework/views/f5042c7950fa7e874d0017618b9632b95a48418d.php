<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<div class="container">
    <div class="row">
        <div class="col-md-6">

                <form method="POST" action="<?php echo e(url('/insert ')); ?>">
                    <?php echo e(csrf_field()); ?>

         <fieldset>
             <legend>INOFINITY CRUD APPLICATION</legend>
      <?php if(count($errors)>0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <div class="alert alert-dismissible alert-danger">
            <?php echo e($error); ?>

          </div>
      
      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
      <?php endif; ?>
            <div class="form-group">
            <label for="InputPassword1">Title</label>
                  <input type="text" name="title" class="form-control" id="title" placeholder="Title">
              </div>

              <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" class="form-control" id="description" placeholder="Description" rows="3"></textarea>
                  </div>


            <div class="form-group">   
                 <button type="submit" class="btn btn-success">Submit</button>
                 <a href="<?php echo e(url('/')); ?>" class="btn btn-success">Back</a>
                </div>  
                 </fieldset>
                
             </form>

        </div>
    </div>
</div>
<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
