<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

 
Route::get('/','createscontroller@home');
Route::get('/create',function(){
    Return view('create');
});
Route::post('/insert','createscontroller@add');
Route::get('/update/{id}','createscontroller@update');
Route::post('/edit/{id}','createscontroller@edit');
Route::get('/read/{id}','createscontroller@read');
Route::get('/delete/{id}','createscontroller@delete');