@include('include.header')
<br>
<div class="container">
    <div class="row">
     <legend><h4>INOFINITY CRUD APPLICATION</h4></legend> 
     
     @if (session('info'))

     <div class="alert alert-dismissible alert-success">

        {{session('info')}}

      </div>
      @endif
    
     
<table class="table table-hover">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Title</th>
            <th scope="col">Description</th>
            <th scope="col">Action</th>
            
          </tr>
        </thead>
        <tbody>
         @if (count($articles) >0)
         @foreach ($articles->all() as $articles)
             
          <tr>
           
            <td>{{$articles->id}}</td>
            <td>{{$articles->title}}</td>
            <td>{{$articles->description}}</td>
            <td>
              <a href='{{url("/read/{$articles->id}")}}' class="btn btn-success btn-sm">Read  </a>
              <a href='{{url("/update/{$articles->id}")}}' class="btn btn-warning btn-sm"">Update</a>
              <a href='{{url("/delete/{$articles->id}")}}' class="btn btn-danger btn-sm" >Delete  </a>   
              
            </td>
          </tr>
          @endforeach
          @endif
        </tbody>
      </table> 
    </div>


      

</div>
@include('include.footer')