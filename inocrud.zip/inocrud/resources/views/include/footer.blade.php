<footer id="footer" class="text text-center">
    <p>Copyright &copy 2019 Inofinity Design</p>
   </footer>

</body>
</html>