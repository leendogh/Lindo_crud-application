@include('include.header')
<br>
<div class="container">
    
     <legend><h4>READ INOFINITY POST</h4></legend>
     <hr>

     <p class="lead">{{$articles->title}}</p>
     <p>{{$articles->description}}</p>
    
</div>
@include('include.footer')